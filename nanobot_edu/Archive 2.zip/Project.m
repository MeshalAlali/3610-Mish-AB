%% Setup %%
% connect robot
clc
clear all
nb = nanobot('/dev/cu.usbmodem1101', 115200, 'serial');

%% PID Loops %%
% Setup gain variables
% Initialize integral, previous error, and previous time terms
% Initialize or perform calculations for targets/values your loop will be working with
% tic
% small delay to prevent toc from blowing up derivative term on first loop

% begin while
	% calculate dt based on toc and previous time
	% update previous time
	% take reading of data
	% Perform conditional checking whether we want to exit the loop (e.g. read all black on reflectance array during line following)
		% exit the loop if so, and perform any needed end behaviors (e.g. setting motors to zero)
	% calculate error term
	% use error to calculate/update integral and derivative terms
	% calculate control signal based on error, integral, and derivative
	% update previous error
	% calculate desired setpoint quantities from control signal
	% apply limits to setpoints if needed
	% apply setpoint to plant (e.g. setting duty cycle for motors)

%% MAIN LOOP %%
% SENSOR INIT
nb.initReflectance();
nb.initUltrasonic1('D2','D3');
nb.initUltrasonic2('D4','D5');

% RUN COURSE
followLine(nb);

pause(0.10); % settle
turn180(nb);

pause(0.10); % settle
followLine(nb);

pause(0.10); % settle
followWall(nb);

%% Gesture Classification %%
% initialize variable to track whether we’ve given valid input
% define list of possible output values, in the order that the network was trained on
% while we haven’t given valid input
	% perform gesture classification as we had done in labs 4 and 5 (outputs index of classified output according to the output value list)
	% let user know what was gesture was classified as, and ask to verify
	% perform gesture classification again
	% check if the first gesture was verified according to the second gesture.
		% if so, set valid input variable such that we exit the loop on the next iteration
		% if not, proceed to the next iteration of the loop

%% Line Following %%
function followLine(nb)
    integral = 0; % i state
    prevError = 0; % last error
    prevTime = 0; % last time

    drive(nb, 83, 83, 0.03); % wake motors

    tic
    pause(0.03); % avoid tiny dt

    % PID LOOP
    while toc < 99 % runtime cap
        dt = toc - prevTime;
        prevTime = toc;

        if dt <= 0
            continue
        end

        vals = nb.reflectanceRead();
        vals = [vals.one, vals.two, vals.three, vals.four, vals.five, vals.six];

        if allBlack(vals)
            drive(nb, 0, 0);
            break
        end

        if allWhite(vals)
            drive(nb, 0, 0);
            break
        end

        % PID
        cal = calibrate(vals);
        error = sum([-3 -2 -1 1 2 3] .* cal) / sum(cal); % line pos
        [control, integral, prevError] = pidStep(error, prevError, integral, dt, 10, 0, 0.5);

        % STEERING
        leftDuty = 9 + control; % left target
        rightDuty = 9 - control; % right target

        leftDuty = min(max(leftDuty, -12), 12); % cap pwm
        rightDuty = min(max(rightDuty, -12), 12); % cap pwm

        drive(nb, leftDuty / 12 * 100, 1.2 * rightDuty / 12 * 100); % send percent
    end

    drive(nb, 0, 0);
end

%% Wall Following %% 
%(True distance-maintaining)
% Set up PID loop
	% Check for all black condition (made a complete circle)
	% Calculate error as the difference between the distance you intend to follow and the measured ultrasonic distance
	% Use prior values of error and/or motor setpoints/encoder rates to determine if the robot is reading a point in front of or behind it, and correct the control signal/motor setpoints accordingly to stabilize.

function followWall(nb)
    integral = 0; % i state
    prevError = 0; % last error
    prevTime = 0; % last time

    sawAllWhite = false; % state flag
    prevSideDistance = 500; % fallback read

    drive(nb, 83, 83, 0.03); % wake motors

    % DRIVE TO WALL
    while true
        frontDistanceCm = nb.ultrasonicRead1() * 0.01615; % raw to cm

        if frontDistanceCm <= 10 % front stop
            break
        end

        drive(nb, 67, 80); % forward
    end

    drive(nb, 0, 0);
    pause(0.10); % settle

    % TURN START
    turn90(nb);
    pause(0.10); % settle

    % WALL LOOP
    tic
    while toc < 60 % runtime cap
        dt = toc - prevTime;
        prevTime = toc;

        if dt <= 0
            continue
        end

        vals = nb.reflectanceRead();
        vals = [vals.one, vals.two, vals.three, vals.four, vals.five, vals.six];

        if ~sawAllWhite
            if allWhite(vals)
                sawAllWhite = true;
            end
        else
            if someBlack(vals)
                break
            end
        end

        sideDistanceRaw = nb.ultrasonicRead2();
        frontDistanceCm = nb.ultrasonicRead1() * 0.01615; % raw to cm

        if sideDistanceRaw <= 0 % bad read
            sideDistanceRaw = prevSideDistance;
        end

        error = 500 - sideDistanceRaw; % side target
        [control, integral, prevError] = pidStep(error, prevError, integral, dt, 3.5, 0, 0.8);

        if frontDistanceCm < 13 % corner bias
            control = control - 2.5;
        end

        prevSideDistance = sideDistanceRaw; % save read

        leftDuty = 8 - control; % left target
        rightDuty = 8 + control; % right target

        leftDuty = min(max(leftDuty, -11), 11); % cap pwm
        rightDuty = min(max(rightDuty, -11), 11); % cap pwm

        drive(nb, leftDuty / 12 * 100, 1.2 * rightDuty / 12 * 100); % send percent
    end

    drive(nb, 0, 0);
end

%% Odometry %% 
%(Straight-line)
% Set up PID loop
	% Using measurements of wheel geometry, calculate the needed encoder counts that each motor needs to go
	% Define a default speed for the robot to move at
	% Calculate the error as being the difference between the motor encoder rates (either countspersec or counts divided by a measured dt)
	% Keep track of the total number of encoder counts for one or both motors and exit the loop and stop the motors once you reach the number of encoder counts needed to travel a certain distance.
		% Alternatively, you could just drive and continue until another condition is met (e.g. the RGB sensor reads red)

%(Angular)
% Set up PID loop
	% Using measurements of wheel geometry, calculate the needed encoder counts that each motor needs to go
	% Similarly to the straight line case, we can monitor the encoder counts/rates until we match the needed value, or come within a certain threshold of it.

%% Helpers %%
% line helpers

% turn 90
function turn90(nb)
    sawAllWhite = false; % state flag

    nb.initReflectance(); % sensor init

    % TURN LOOP
    while true
        vals = nb.reflectanceRead();
        vals = [vals.one, vals.two, vals.three, vals.four, vals.five, vals.six];

        drive(nb, -67, -67); % rotate

        if ~sawAllWhite
            if allWhite(vals)
                sawAllWhite = true;
            end
        else
            if someBlack(vals)
                break
            end
        end
    end

    drive(nb, 0, 0);
end

% turn 180
function turn180(nb)
    sawAllWhite = false; % state flag

    nb.initReflectance(); % sensor init

    % TURN LOOP
    while true
        vals = nb.reflectanceRead();
        vals = [vals.one, vals.two, vals.three, vals.four, vals.five, vals.six];

        drive(nb, -67, -67); % rotate

        if ~sawAllWhite
            if allWhite(vals)
                sawAllWhite = true;
            end
        else
            if someBlack(vals)
                break
            end
        end
    end

    drive(nb, 0, 0);
end

% thresholds
function t = whiteThresh(), t = 200; end
function t = blackThresh(), t = 700; end

% calibrate raw vals to 0-1 using thresholds
function cal = calibrate(vals)
    cal = (vals - whiteThresh()) / (blackThresh() - whiteThresh());
end

% reflectance checks
function r = allWhite(vals), r = all(vals < whiteThresh()); end
function r = allBlack(vals), r = all(vals > blackThresh()); end
function r = someBlack(vals), r = any(vals > blackThresh()); end

% pid step
function [control, integral, prevError] = pidStep(error, prevError, integral, dt, Kp, Ki, Kd)
    integral = integral + error * dt; % i update
    derivative = (error - prevError) / dt; % d term
    control = Kp * error + Ki * integral + Kd * derivative; % pid out
    prevError = error;
end

% motor drive
function drive(nb, leftSpeed, rightSpeed, duration)
    leftDuty = min(max(leftSpeed, -100), 100) / 100 * 12; % scale left
    rightDuty = min(max(rightSpeed, -100), 100) / 100 * 12; % scale right

    if nargin < 4
        nb.setMotor(1, leftDuty);
        nb.setMotor(2, rightDuty);
    else
        nb.setMotor(1, leftDuty);
        nb.setMotor(2, rightDuty);
        pause(duration);
        nb.setMotor(1, 0);
        nb.setMotor(2, 0);
    end
end

%% X. DISCONNECT
%  Clears the workspace and command window, then
%  disconnects from the nanobot, freeing up the serial port.

% DISCONNECT ROBOT
clc

if exist('nb','var')
    drive(nb, 0, 0); % stop motors
    delete(nb); % close robot
    clear('nb'); % clear robot
end

clear all

%% EMERGENCY MOTOR SHUT OFF
% If this section doesn't turn off the motors, turn off the power switch 
% on your motor carrier board.

% CLEAR MOTORS
    drive(nb, 0, 0); % stop motors